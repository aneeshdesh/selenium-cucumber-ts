import { expect } from "chai";
import { Given, When, Then } from "@cucumber/cucumber";

Given("a comparision", function() {
    this.comparision = {
        compare(n1: string, n2: string): string {
            if(n1 == n2){
                return "matched";
            }else{
                return "unmatched";  
            }  
        }
    };
});
 
When("I compare {string} with {string}", function(n1: string, n2: string) {
    this.actual = this.comparision.compare(n1, n2);
});
 
Then("the result is {string}", function(expected: string) {
    console.log(expect(this.actual).to.be.equal(expected));
   // console.log(this.actual);
});