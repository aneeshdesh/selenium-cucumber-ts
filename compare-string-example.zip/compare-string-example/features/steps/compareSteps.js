"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chai_1 = require("chai");
const cucumber_1 = require("@cucumber/cucumber");
(0, cucumber_1.Given)("a comparision", function () {
    this.comparision = {
        compare(n1, n2) {
            if (n1 == n2) {
                return "matched";
            }
            else {
                return "unmatched";
            }
        }
    };
});
(0, cucumber_1.When)("I compare {string} with {string}", function (n1, n2) {
    this.actual = this.comparision.compare(n1, n2);
});
(0, cucumber_1.Then)("the result is {string}", function (expected) {
    console.log((0, chai_1.expect)(this.actual).to.be.equal(expected));
    // console.log(this.actual);
});
