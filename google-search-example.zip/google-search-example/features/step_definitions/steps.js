var assert = require('assert');
var seleniumWebdriver = require('selenium-webdriver');
const { By, Key, until } = seleniumWebdriver;


module.exports = function () {
  this.Given(/^I visit google$/, function() {
    
    return this.driver.get('https://www.google.com/');
  });
  this.When(/^I search for "([^"]*)"$/, function (arg1, callback) {
    // Write code here that turns the phrase above into concrete actions    
    var element = this.driver.findElement(By.name('q'));
    element.sendKeys(arg1, Key.RETURN);   
    element.submit();

    this.driver.wait(until.elementLocated(By.name('q')));  

  });
  this.Then(/^the page title should start with "([^"]*)"$/, function(arg1, callback) {
    this.driver.getTitle().then(function (title) {
    // console.log(title);
     // const isTitleStartWithCheese = title.toLowerCase().lastIndexOf(`${arg1}`, 0) === 0;
      assert.equal(title, "Cheese! - Google Search");
      return title;
    });
  });

  
};
