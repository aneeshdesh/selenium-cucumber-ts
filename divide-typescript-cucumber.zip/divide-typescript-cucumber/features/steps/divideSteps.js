"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chai_1 = require("chai");
const cucumber_1 = require("@cucumber/cucumber");
//import { Calculator } from "../../src/calculator";
(0, cucumber_1.Given)("a calculator", function () {
    this.calculator = {
        divide(n1, n2) {
            //throw new Error("Not implemented");
            return n1 / n2;
        }
    };
});
(0, cucumber_1.When)("I divide {int} by {int}", function (n1, n2) {
    this.actual = this.calculator.divide(n1, n2);
});
(0, cucumber_1.Then)("the result is {int}", function (expected) {
    (0, chai_1.expect)(this.actual).to.be.equal(expected);
});
