export class Calculator {
    divide(n1: number, n2: number): number {
        return n1 / n2;
    }
}