var assert = require('assert');

module.exports = function () {
  this.Given(/^I visit selenium$/, function() {
    return this.driver.get('https://www.selenium.dev/');
  });

  this.Then(/^I should see Selenium in title$/, function() {
    this.driver.getTitle().then(function (title) {
      assert.equal(title, "Selenium");
      return title;
    });
  });

  
};
